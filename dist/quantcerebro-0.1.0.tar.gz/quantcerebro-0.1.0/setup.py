# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['quantcerebro']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0', 'eventkit>=0.8.9,<0.9.0']

entry_points = \
{'console_scripts': ['poetry = poetry.console:run']}

setup_kwargs = {
    'name': 'quantcerebro',
    'version': '0.1.0',
    'description': '',
    'long_description': 'QuantCerebro\n============\n\nQuantCerebro is a Python package for building event driven programs. It provides a simple and configurable framework to\ndefine Callable (Interface) dependency and Event dependency.\n',
    'author': 'Jacob Tian',
    'author_email': 'olivandertian@yahoo.com',
    'maintainer': 'Jacob Tian',
    'maintainer_email': 'olivandertian@yahoo.com',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
