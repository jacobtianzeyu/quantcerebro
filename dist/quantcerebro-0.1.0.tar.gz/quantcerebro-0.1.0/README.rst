QuantCerebro
============

QuantCerebro is a Python package for building event driven programs. It provides a simple and configurable framework to
define Callable (Interface) dependency and Event dependency.
